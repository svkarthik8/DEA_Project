# Twitter Sentiment Analysis using Big Data

## Tools Used
- Hadoop (HDFS for storage)
- Apache Spark (for fast distributed processing)
- Python (Flask for Dashboard, Pandas for Visualization)

## Project Structure
- `data/`: Raw source data.
- `hadoop/`: Scripts to interact with HDFS.
- `spark/`: Core Spark logic for sentiment analysis.
- `dashboard/`: Premium web-based analytics dashboard.
- `visualization/`: CLI-based plots.

## Steps to Run
1. **Start Hadoop Services**:
   ```bash
   start-dfs.sh
   ```
2. **Upload Data to HDFS**:
   ```bash
   bash hadoop/upload_to_hdfs.sh
   ```
3. **Run Spark Processing**:
   ```bash
   spark-submit --py-files utils/preprocess.py spark/sentiment_analysis.py
   ```
4. **Launch Dashboard**:
   ```bash
   python dashboard/server.py
   ```
   Open `http://localhost:5000` in your browser.

## Output
- Sentiment classification (Positive/Negative/Neutral).
- Interactive dashboard with real-time stats and distribution charts.
