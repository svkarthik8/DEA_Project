from flask import Flask, jsonify, send_from_directory
import pandas as pd
import glob
import os

app = Flask(__name__, static_folder='static')

# Path to the Spark output directory
RESULTS_DIR = os.path.join(os.path.dirname(__file__), '..', 'output', 'results.csv')

def get_latest_data():
    """Reads all part-files from the Spark output directory and merges them."""
    if not os.path.exists(RESULTS_DIR):
        print(f"Error: Path {RESULTS_DIR} does not exist.")
        return pd.DataFrame()
    
    # Spark output contains multiple part-xxxx.csv files
    path_pattern = os.path.join(RESULTS_DIR, "*.csv")
    all_files = glob.glob(path_pattern)
    
    if not all_files:
        print(f"No CSV files found in {RESULTS_DIR}")
        return pd.DataFrame()
    
    # Combine all part files into one DataFrame
    df_list = [pd.read_csv(f) for f in all_files]
    return pd.concat(df_list, ignore_index=True)

@app.route('/')
def index():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/api/data')
def get_data():
    df = get_latest_data()
    if df.empty:
        return jsonify({"error": "No data found. Ensure Spark job has run."}), 404
    
    # Calculate sentiment distribution
    sentiment_counts = df['sentiment'].value_counts().to_dict()
    
    # Get top 10 recent tweets for display
    recent_tweets = df[['tweet', 'sentiment']].head(10).to_dict(orient='records')
    
    stats = {
        "total": len(df),
        "sentiment_counts": sentiment_counts,
        "recent_tweets": recent_tweets
    }
    return jsonify(stats)

if __name__ == '__main__':
    print("Dashboard Server starting on http://localhost:5000")
    app.run(debug=True, port=5000)
