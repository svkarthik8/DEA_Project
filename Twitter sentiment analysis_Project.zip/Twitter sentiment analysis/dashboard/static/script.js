let sentimentChart = null;

async function fetchData() {
    const btn = document.querySelector('.btn-refresh');
    btn.textContent = 'Refreshing...';
    btn.disabled = true;

    try {
        const response = await fetch('/api/data');
        const data = await response.json();

        if (response.status === 404) {
            alert("No data found! Please make sure you have run the Spark job and the output/results.csv folder exists.");
            return;
        }

        updateDashboard(data);
    } catch (error) {
        console.error("Error fetching data:", error);
        alert("Failed to connect to the backend server.");
    } finally {
        btn.textContent = 'Refresh Dashboard';
        btn.disabled = false;
        document.getElementById('last-updated').textContent = `Last Updated: ${new Date().toLocaleTimeString()}`;
    }
}

function updateDashboard(data) {
    // 1. Update Stats
    document.getElementById('total-count').textContent = data.total.toLocaleString();
    
    const counts = data.sentiment_counts;
    const pos = counts['Positive'] || 0;
    const neg = counts['Negative'] || 0;
    const neu = counts['Neutral'] || 0;

    const posPct = ((pos / data.total) * 100).toFixed(1);
    const negPct = ((neg / data.total) * 100).toFixed(1);

    document.getElementById('pos-percent').textContent = `${posPct}%`;
    document.getElementById('neg-percent').textContent = `${negPct}%`;
    document.getElementById('pos-fill').style.width = `${posPct}%`;
    document.getElementById('neg-fill').style.width = `${negPct}%`;

    // 2. Update Chart
    const ctx = document.getElementById('sentimentChart').getContext('2d');
    
    if (sentimentChart) {
        sentimentChart.destroy();
    }

    sentimentChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Positive', 'Negative', 'Neutral'],
            datasets: [{
                data: [pos, neg, neu],
                backgroundColor: ['#10b981', '#ef4444', '#6b7280'],
                borderColor: 'rgba(255, 255, 255, 0.1)',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: '#f3f4f6', padding: 20 }
                }
            },
            cutout: '70%'
        }
    });

    // 3. Update Table
    const tbody = document.getElementById('tweet-tbody');
    tbody.innerHTML = '';

    data.recent_tweets.forEach(tweet => {
        const row = document.createElement('tr');
        const labelClass = `label-${tweet.sentiment.toLowerCase()}`;
        
        row.innerHTML = `
            <td>${tweet.tweet}</td>
            <td><span class="sentiment-label ${labelClass}">${tweet.sentiment}</span></td>
        `;
        tbody.appendChild(row);
    });
}

// Initial fetch
document.addEventListener('DOMContentLoaded', fetchData);
