#!/bin/bash

hdfs dfs -mkdir -p /twitter_data
hdfs dfs -put data/tweets.csv /twitter_data/
