from pyspark.sql import SparkSession
from textblob import TextBlob
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType
import os
import sys

# Ensure utils is in the path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from utils.preprocess import clean_text

# Create Spark session
spark = SparkSession.builder.appName("TwitterSentiment").getOrCreate()

# Load data from HDFS (or local for testing)
# Using a flexible path that can be overridden by spark-submit arguments if needed
try:
    df = spark.read.csv("hdfs://localhost:9000/twitter_data/tweets.csv", header=True)
except Exception as e:
    print("HDFS not available, trying local data/tweets.csv...")
    df = spark.read.csv("data/tweets.csv", header=True)

# Preprocess function
def preprocess(text):
    return clean_text(text)

preprocess_udf = udf(preprocess, StringType())

df = df.withColumn("clean_tweet", preprocess_udf(df["tweet"]))

# Sentiment function
def get_sentiment(text):
    polarity = TextBlob(text).sentiment.polarity
    if polarity > 0:
        return "Positive"
    elif polarity < 0:
        return "Negative"
    else:
        return "Neutral"

sentiment_udf = udf(get_sentiment, StringType())

df = df.withColumn("sentiment", sentiment_udf(df["clean_tweet"]))

# Save results
output_path = "output/results.csv"
df.write.mode("overwrite").csv(output_path, header=True)

# Show output
df.show()
