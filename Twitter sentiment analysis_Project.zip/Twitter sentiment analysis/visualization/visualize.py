import pandas as pd
import matplotlib.pyplot as plt
import glob
import os

# Path to the Spark output directory
results_path = os.path.join(os.path.dirname(__file__), '..', 'output', 'results.csv')

# Spark saves as a directory of part files
all_files = glob.glob(os.path.join(results_path, "*.csv"))
if not all_files:
    print(f"No results found in {results_path}")
    exit(1)

df_list = [pd.read_csv(f) for f in all_files]
df = pd.concat(df_list, ignore_index=True)

counts = df["sentiment"].value_counts()

plt.figure(figsize=(10, 6))
counts.plot(kind="bar", color=['#10b981', '#ef4444', '#6b7280'])
plt.title("Twitter Sentiment Analysis Results")
plt.xlabel("Sentiment")
plt.ylabel("Count")
plt.grid(axis='y', linestyle='--', alpha=0.7)

plt.show()
